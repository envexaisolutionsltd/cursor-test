import { NextResponse } from 'next/server';
import { fetchWithTimeout, jsonError } from '@/lib/world/http';

export const dynamic = 'force-dynamic';
export const maxDuration = 15;

let cache: {at:number; body:any}|null = null;
const TTL = 10_000;

export async function GET() {
  if (cache && Date.now() - cache.at < TTL) return NextResponse.json(cache.body,{headers:{'x-gev-cache':'HIT'}});
  try {
    const upstream = await fetchWithTimeout('https://api.adsb.lol/v2/mil', { headers:{accept:'application/json'} }, 9_000);
    if (!upstream.ok) throw new Error(`adsb.lol HTTP ${upstream.status}`);
    const body = await upstream.json();
    cache = {at:Date.now(), body};
    return NextResponse.json(body,{headers:{'x-gev-cache':'MISS'}});
  } catch (error) {
    if (cache) return NextResponse.json(cache.body,{headers:{'x-gev-cache':'STALE'}});
    return NextResponse.json(jsonError(error,'Military flight source unavailable'),{status:502});
  }
}
