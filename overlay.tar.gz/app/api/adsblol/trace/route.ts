import { NextRequest, NextResponse } from 'next/server';
import { fetchWithTimeout, jsonError } from '@/lib/world/http';

export const dynamic = 'force-dynamic';
export const maxDuration = 15;

export async function GET(request: NextRequest) {
  const hex = String(request.nextUrl.searchParams.get('hex') || '').trim().toLowerCase();
  if (!/^[0-9a-f]{6}$/.test(hex)) return NextResponse.json({error:'invalid hex'},{status:400});
  try {
    const upstream = await fetchWithTimeout(`https://api.adsb.lol/v2/trace/${hex}`, {headers:{accept:'application/json'}}, 9_000);
    const text = await upstream.text();
    return new NextResponse(text,{status:upstream.status,headers:{'content-type':upstream.headers.get('content-type') || 'application/json','cache-control':'no-store'}});
  } catch (error) {
    return NextResponse.json(jsonError(error,'Aircraft trace unavailable'),{status:502});
  }
}
