import { NextRequest, NextResponse } from 'next/server';
import shinjukuSources from '@/config/cctv_sources.shinjuku.json';
import austinSources from '@/config/cctv_sources.austin.json';

export const dynamic = 'force-dynamic';
export const maxDuration = 15;

type CameraSource = {
  id:string; name:string; city?:string; cityId?:string; provider?:string; sourceKind?:string;
  feedType?:string; url?:string; lat:number; lon:number; headingDeg?:number; pitchDeg?:number;
  fovDeg?:number; rangeM?:number; mountHeightM?:number; groundElevationM?:number; license?:string;
};

const SOURCES: CameraSource[] = [...(shinjukuSources as CameraSource[]), ...(austinSources as CameraSource[])];
const byId = new Map(SOURCES.map((source) => [source.id, source]));

function sourceView(source: CameraSource) {
  return { ...source, url: source.url || null };
}

function syntheticFrame(source: CameraSource | null, request: NextRequest) {
  const label = String(request.nextUrl.searchParams.get('label') || source?.name || 'CCTV').slice(0, 48);
  const city = String(request.nextUrl.searchParams.get('city') || source?.city || 'GLOBAL').slice(0, 32);
  const safe = (value:string) => value.replace(/[&<>"']/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]!));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="540" viewBox="0 0 960 540"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#031019"/><stop offset="1" stop-color="#010407"/></linearGradient></defs><rect width="960" height="540" fill="url(#g)"/><g fill="none" stroke="#00d4ff" stroke-opacity=".22"><rect x="20" y="20" width="920" height="500"/><rect x="42" y="42" width="876" height="456"/></g><text x="54" y="92" fill="#aef6ff" font-size="32" font-family="monospace" font-weight="700">${safe(label)}</text><text x="54" y="132" fill="#79d9e8" font-size="22" font-family="monospace">${safe(city.toUpperCase())}</text><text x="54" y="490" fill="#5fb8c7" font-size="19" font-family="monospace">FREE MODE · SYNTHETIC FALLBACK</text></svg>`;
}

export async function GET(request: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const { path } = await context.params;
  const [action, encodedId] = path || [];
  const id = encodedId ? decodeURIComponent(encodedId) : '';
  const source = id ? byId.get(id) || null : null;

  if (action === 'sources') {
    return NextResponse.json({ sources: SOURCES.map(sourceView), count: SOURCES.length, source: 'bundled-free-demo' }, { headers: { 'cache-control': 'public, max-age=300' } });
  }
  if (action === 'health') {
    return NextResponse.json({
      cameras: SOURCES.map((camera) => ({ id: camera.id, status: camera.url ? 'configured' : 'fallback', sourceKind: camera.sourceKind || camera.feedType || 'pilot', label: camera.provider || 'Bundled free demo', message: camera.url ? 'public demo feed configured' : 'synthetic fallback', updatedAt: Date.now() })),
    }, { headers: { 'cache-control': 'no-store' } });
  }
  if (action === 'stream') {
    if (!source) return NextResponse.json({ error: 'Camera not found' }, { status: 404 });
    return NextResponse.json({
      id: source.id,
      feedType: source.feedType || 'image',
      configured: Boolean(source.url),
      mediaUrl: `/api/cctv/media/${encodeURIComponent(source.id)}`,
      frameUrl: `/api/cctv/frame/${encodeURIComponent(source.id)}`,
      sourceKind: source.sourceKind || 'pilot',
    });
  }
  if (action === 'media') {
    if (!source) return NextResponse.json({ error: 'Camera not found' }, { status: 404 });
    if (!source.url) return new NextResponse(syntheticFrame(source, request), { status: 200, headers: { 'content-type': 'image/svg+xml; charset=utf-8', 'cache-control': 'public, max-age=10' } });
    return NextResponse.redirect(source.url, 307);
  }
  if (action === 'frame') {
    // Video frame extraction would require Chromium/ffmpeg and would burn Hobby
    // function time. The projection plane uses /media for configured MP4 feeds;
    // this endpoint stays a deterministic, always-available image fallback.
    return new NextResponse(syntheticFrame(source, request), { status: 200, headers: { 'content-type': 'image/svg+xml; charset=utf-8', 'cache-control': 'public, max-age=10' } });
  }

  return NextResponse.json({ error: 'Unknown CCTV endpoint' }, { status: 404 });
}
