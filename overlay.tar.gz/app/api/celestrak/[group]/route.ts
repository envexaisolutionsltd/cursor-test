import { NextResponse } from 'next/server';
import { fetchWithTimeout } from '@/lib/world/http';

export const dynamic = 'force-dynamic';
export const maxDuration = 20;

const memory = new Map<string,{at:number;body:string}>();
const TTL = 6 * 60 * 60_000;

export async function GET(_request: Request, context: {params: Promise<{group:string}>}) {
  const {group} = await context.params;
  if (!/^[a-z0-9-]+$/i.test(group)) return new NextResponse('invalid group',{status:400});
  const cached = memory.get(group);
  if (cached && Date.now()-cached.at<TTL) return new NextResponse(cached.body,{headers:{'content-type':'text/plain','x-tle-cache':'HIT'}});
  try {
    const url = new URL('https://celestrak.org/NORAD/elements/gp.php');
    url.searchParams.set('GROUP',group);
    url.searchParams.set('FORMAT','tle');
    const upstream = await fetchWithTimeout(url,{headers:{accept:'text/plain'}},15_000);
    if (!upstream.ok) throw new Error(`CelesTrak HTTP ${upstream.status}`);
    const body = await upstream.text();
    if (!/^1 /m.test(body)) throw new Error('CelesTrak returned no TLE lines');
    memory.set(group,{at:Date.now(),body});
    return new NextResponse(body,{headers:{'content-type':'text/plain','x-tle-cache':'MISS','cache-control':'public, max-age=3600'}});
  } catch (error) {
    if (cached) return new NextResponse(cached.body,{headers:{'content-type':'text/plain','x-tle-cache':'STALE-ERROR'}});
    return new NextResponse(`celestrak unavailable: ${error instanceof Error?error.message:'unknown error'}`,{status:502});
  }
}
