import { NextResponse } from 'next/server';
import { fetchWithTimeout } from '@/lib/world/http';

export const dynamic='force-dynamic';
export const maxDuration=12;

const memory=new Map<string,{at:number;value:any}>();
const TTL=24*60*60_000;

function parseRoute(json:any){const fr=json?.response?.flightroute;if(!fr?.origin||!fr?.destination)return null;const airport=(a:any)=>({code:a.iata_code||a.icao_code||'',name:a.municipality||a.name||'',lat:Number.isFinite(a.latitude)?a.latitude:null,lon:Number.isFinite(a.longitude)?a.longitude:null});return{airline:fr.airline?.name||null,origin:airport(fr.origin),destination:airport(fr.destination)};}
function parseAircraft(json:any){const a=json?.response?.aircraft;if(!a)return null;return{typeCode:a.icao_type||null,typeName:a.manufacturer&&a.type?`${a.manufacturer} ${a.type}`:(a.type||null),registration:a.registration||null,manufacturer:a.manufacturer||null};}

export async function GET(_request:Request,context:{params:Promise<{kind:string;key:string}>}){
  const {kind,key}=await context.params;const decoded=decodeURIComponent(key).trim();
  if(!['route','type'].includes(kind)||!decoded||decoded.length>32)return NextResponse.json({error:'invalid enrichment request'},{status:400});
  const cacheKey=`${kind}:${decoded.toLowerCase()}`;const hit=memory.get(cacheKey);if(hit&&Date.now()-hit.at<TTL)return NextResponse.json(hit.value??{});
  try{const path=kind==='route'?`callsign/${encodeURIComponent(decoded)}`:`aircraft/${encodeURIComponent(decoded.toLowerCase())}`;const upstream=await fetchWithTimeout(`https://api.adsbdb.com/v0/${path}`,{headers:{accept:'application/json'}},8_000);if(upstream.status===404){memory.set(cacheKey,{at:Date.now(),value:{}});return NextResponse.json({});}if(!upstream.ok)throw new Error(`adsbdb HTTP ${upstream.status}`);const raw=await upstream.json();const value=kind==='route'?parseRoute(raw):parseAircraft(raw);memory.set(cacheKey,{at:Date.now(),value:value||{}});return NextResponse.json(value||{});}catch(error){return NextResponse.json({error:error instanceof Error?error.message:'enrichment unavailable'},{status:502});}
}
