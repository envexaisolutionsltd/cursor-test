import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

function unavailable(extra: Record<string,unknown> = {}) {
  const configured = Boolean(process.env.AISSTREAM_API_KEY?.trim());
  return NextResponse.json({
    rows: [],
    source: 'AISStream',
    status: configured ? 'serverless_unsupported' : 'no_key',
    error: configured
      ? 'AISStream requires a persistent WebSocket worker; Vercel serverless FREE mode cannot keep that socket alive.'
      : 'AISSTREAM_API_KEY is not configured. Vessels are optional in FREE mode.',
    refreshing: false,
    lastMessageAt: null,
    ...extra,
  }, { status: 503, headers: { 'cache-control':'no-store' } });
}

export async function GET(request: NextRequest, context: { params: Promise<{ path?: string[] }> }) {
  const { path } = await context.params;
  if (path?.[0] === 'track') {
    const mmsi = String(request.nextUrl.searchParams.get('mmsi') || '').trim();
    if (!/^\d{5,10}$/.test(mmsi)) return NextResponse.json({ error:'mmsi query param required', samples:[] },{status:400});
    return unavailable({ mmsi, samples:[], retainedSec:0 });
  }
  return unavailable();
}
