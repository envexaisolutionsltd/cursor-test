import { NextRequest, NextResponse } from 'next/server';
import { captureWebsite } from '@/lib/commercial/capture';

export const dynamic = 'force-dynamic';
export const maxDuration = 30;

export async function GET(request: NextRequest) {
  try {
    const url = request.nextUrl.searchParams.get('url') || '';
    const viewport = request.nextUrl.searchParams.get('viewport') === 'mobile' ? 'mobile' : 'desktop';
    if (!url) return NextResponse.json({error:'url is required'},{status:400});
    const bytes = await captureWebsite(url, viewport);
    return new NextResponse(bytes as BodyInit, { headers: { 'content-type':'image/jpeg', 'cache-control':'public, max-age=3600, s-maxage=86400' } });
  } catch (error) {
    return NextResponse.json({error:error instanceof Error ? error.message : 'Capture failed'},{status:422});
  }
}
