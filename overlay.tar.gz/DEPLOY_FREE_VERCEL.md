# Deploy FREE mode to Vercel

## Baseline: no keys required

1. Push the contents of this folder to your Git repository root.
2. Import that repository into Vercel.
3. Framework preset: Next.js (normally detected automatically).
4. Do not override the build command. `npm run build` is correct.
5. Deploy.

The build runs these gates automatically:

```text
npm run validate
npm test
npm run build:client
next build
```

The original God’s Eye Vite client is built into `public/gev`; Next.js serves all same-origin APIs and redirects `/` to the original UI.

## Optional free-tier keys

Add only if wanted:

```text
GEOAPIFY_API_KEY=
GEMINI_API_KEY=
GEMINI_MODEL=gemini-3.5-flash-lite
```

After changing environment variables, redeploy.

## Expected zero-key behaviour

- Globe: Esri World Imagery, with OSM automatic fallback.
- Commercial discovery: Overture Maps PMTiles.
- Website audit: deterministic HTTP/HTML analysis.
- Visual AI: deterministic fallback until Gemini is configured.
- Screenshots: Vercel-hosted Chromium, best effort.
- Google Places / Cesium ion / OpenAI / Browserless: not required.
- AIS live vessels: disabled on Vercel serverless FREE mode because AISStream needs a persistent WebSocket worker.
- FIRMS fires: disabled until an optional FIRMS key is supplied.

## First live test

Open **COMMERCIAL RECON** and run QUICK mode:

> Find independent gyms around Manchester with weak websites.

Then try:

> Give me the top 10 countries for gym businesses with weak websites.

If a Vercel build/runtime issue occurs, save the complete log rather than changing provider keys blindly.

## Free screenshot runtime

`npm install` runs `scripts/postinstall-chromium.mjs`. It packages the build-time
`@sparticuz/chromium` Brotli assets into `public/chromium-pack.tar`. Runtime
functions use the smaller `@sparticuz/chromium-min` package and extract that
same deployment-hosted archive on first capture. No Browserless account or key
is needed.

If you self-host locally, set `PUPPETEER_EXECUTABLE_PATH` to a local Chrome or
Chromium binary. `CHROMIUM_PACK_URL` is an advanced override only.

## v0.6.2 deployment note

This release fixes two dependency-API build blockers found by real Vercel builds:

- the original-client builder now calls Vite through its supported `build()` JavaScript API rather than resolving a private `vite/bin/*` subpath;
- Overture vector-tile decoding now uses pbf v5's `PbfReader` named export.

Critical direct dependencies are pinned, React and React DOM are aligned at 19.2.8, and the prebuild now runs `validate:deps` against the packages Vercel actually installed before any client compilation starts.

### First v0.6.2 redeploy

Because previous logs show Vercel restoring an older build cache, use **Redeploy -> Clear/disable build cache** for the first v0.6.2 deployment. After one clean successful deployment, normal cached deployments can be used again.

No environment variables are required for the keyless FREE baseline.


## v0.6.3 startup fix

For the first v0.6.3 deployment, clear the previous Vercel build cache. This release replaces the old Cesium Vite plugin path with bundled Cesium ESM plus explicit static runtime assets.

A successful build should include this line before Next.js compilation:

`Built client validation passed: ... /gev assets resolved; Cesium ESM runtime directories present.`

After deployment, verify these URLs return 200:

- `/gev/index.html`
- `/gev/cesium/Widgets/widgets.css`

The application no longer requires or references `/gev/cesium/Cesium.js`.

If client startup fails, the splash now changes to `STARTUP ERROR · ...` with the failing stage/error instead of remaining frozen indefinitely.
